package day4;

public class car {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         A c=new MyClass ();
         c.meth1();
         //c.meth2();
	}

}
interface A{
	void meth1();
	void meth2();
}
class MyClass implements A{
	public void meth1() {

		System.out.println("This uses first method to solve the problem ");
		}
	
	public void meth2() {
		
		
		System.out.println("This uses second method to solve the problem");
		}	
		
}