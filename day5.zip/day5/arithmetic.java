package day5;
import java.util.*;
public class arithmetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b;
Scanner scan=new Scanner(System.in);
System.out.println("enter value for a:");
a=scan.nextInt();
System.out.println("enter value for b:");
b=scan.nextInt();
int c;


try {
	c=a/b;
	
		System.out.println("The value of c:"+c);

}
catch(ArithmeticException e) {
	System.out.println("throws error");
}
//System.out.println(c);
	}

}
