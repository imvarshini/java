package day6;

import java.util.ArrayList;

public class languagw {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> a2=new ArrayList<String>();
a2.add("c");
a2.add("java");
a2.add("python");
a2.add("html");
a2.add("DBMS");
a2.add("UI");
System.out.println("ArrayList before remove:");
for(String var:a2) {
	System.out.println(var);
}
a2.remove(0);
a2.remove(2);
a2.remove(2);
System.out.println("array list removed");
for (String var2:a2) {
	System.out.println(var2);
}
	}


}
