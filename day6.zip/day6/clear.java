package day6;
import java.util.*;
import java.io.*;
import java.util.Set;

public class clear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set<String> st = new HashSet<String>();
st.add("welcome all");
st.add("gekks");
st.add("thank");
st.add("you");
System.out.println("Initial set:"+st);
st.clear();
System.out.println("final set:"+st);
	}

}
