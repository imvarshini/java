package day5continue;
import java.util.*;
public class vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int count=0;
System.out.println("Enter the sentence");
Scanner scan=new Scanner(System.in);
String c=scan.nextLine();
 
for(int i=0;i<c.length();i++) {
	char ch=c.charAt(i);
	if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
		count++;
	}
}
System.out.println("number of times vowel occurs:"+count);
	}

}
