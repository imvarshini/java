package day2;
import java.util.Scanner;
public class methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          Scanner scan=new Scanner(System.in);
         
          methods m=new methods();
         
          m.add(34.5f, 665.76f);
          
	}
	
	    void  add (float a,float b) {
		float s=a+b;
		
		System.out.println("sum= "+s);
		
	}

}
