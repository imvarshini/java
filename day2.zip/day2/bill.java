package day2;

import java.util.Scanner;

public class bill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String choice;
       Scanner scan= new Scanner(System.in);
       do {
    	   System.out.println("Bill Of Order");
           
           System.out.print("Select your menu :\n1.Breakfast\n2.Lunch\n3.Dinner");
           int op=scan.nextInt();
       
           if(op==1) {
           System.out.print("Select the order:\n1.Coffee-Rs.20\n2.Dosa-Rs40");
           int ap=scan.nextInt();
           if(ap==1) {
        	   int n1=20;
        	   System.out.println("No of cofee ordered:");
        	   int n=scan.nextInt();
        	   int total=n*n1;
        	   
        	   System.out.println("total:"+total);
        	   
           }
           else {
        	   int n2=40;
        	   System.out.println("No of cofee ordered:");
        	   int n=scan.nextInt();
        	   int total=n*n2;
        	   
        	   System.out.println("total:"+total);
        	   
           }
           }
           else if(op==2) {
        	   System.out.print("Select the order:\n1.Fried Rice-Rs.180\2b.Meals-Rs100");
        	   int mp=scan.nextInt();
        	   if(mp==1) {
        		   int n3=180;
        		   System.out.println("No of cofee ordered:");
            	   int n=scan.nextInt();
            	   int total=n*n3;
            	   
            	   System.out.println("total:"+total);
        		   //System.out.println("total:"+n3);
        	   }
        	   else {
        		   int n4=100;
        		   System.out.println("No of cofee ordered:");
            	   int n=scan.nextInt();
            	   int total=n*n4;
            	   
            	   System.out.println("total:"+total);
        		  // System.out.println("total:"+n4);
        	   }
           }
           else if(op==3){
        	   System.out.print("Select the order:\n1.Butter Nan-Rs.30\n2Kulcha-Rs40");
               int mn=scan.nextInt(); 
               if(mn==1) {
            	   int n5=30;
            	   System.out.println("No of cofee ordered:");
            	   int n=scan.nextInt();
            	   int total=n*n5;
            	   
            	   System.out.println("total:"+total);
            	  // System.out.println("total:"+n5);
               }
               else {
            	   int n6=40;
            	   System.out.println("No of cofee ordered:");
            	   int n=scan.nextInt();
            	   int total=n*n6;
            	   
            	   System.out.println("total:"+total);
            	  // System.out.println("total:"+n6);
               }
           }
       
           
        
       else
           {
    
              System.out.print("Enter valid choice(1,2,3,4)");
        }
           
          System.out.print("Do you want to continue?(yes/no)");
           choice=scan.next();
           }
           while(choice.equals("YES")|| choice.equals("yes"));
           System.out.print("Thankyou!!!");
       
       
}
}