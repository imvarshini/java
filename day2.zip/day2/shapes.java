package day2;

public class shapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       shapes s=new shapes();
       System.out.println("area of circle is= "+s.area(3f));
       System.out.println("area of square is= "+s.area(4));
       System.out.println("area of rectangle is= "+s.area(6,10));
	}
	float area(float a) {
		float p = 3.14f;
		//float r=3f;
		float a1= p*a*a;
		return  a1;
	}
	int area(int b) {
		
		int a2=b*b;
		return a2;
	}
	int area(int l,int w) {
	
		int a3=l*w;
		return a3;
	}

}
