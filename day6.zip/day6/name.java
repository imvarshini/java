package day6;

import java.util.ArrayList;

public class name {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Friend> list=new ArrayList<>();//Object

		Friend s1=new Friend("varshini", "vara", 1234567890);

	    Friend s2=new Friend("domnick", "dom", 173572536);

		Friend s3=new Friend("harshitha", "harshi", 1297578359);
	    Friend s4=new Friend("suheb", "Present", 1234754367);

	    list.add(s1);

	    list.add(s2);

		list.add(s3);

		list.add(s4);

		for( Friend s:list) {
	        System.out.println(s.name+" �"+s.nicName+"  "+s.phoneNo);
	        }

		
	}

}
class Friend {
String name;
String nicName;
int phoneNo;
public Friend(String name,String nicName,int phoneNo) {
	super();
	this.name = name;
	this.nicName=nicName;
	this.phoneNo=phoneNo;
}
}

