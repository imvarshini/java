package day5continue;

public class arrayDuuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {1,2,2,2,3,4,5,6,2};
int n=arr.length;
int x=2;
int res=0;
for(int i=0;i<n;i++) {
	if(x==arr[i])
		res++;
	
}
System.out.println("No of occurence:"+res);
	}

}
