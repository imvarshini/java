package day4;

public class InterfaceX {
	public static void main(String args[]) {
     IVehicle p = new Mahindra();
      p.tuneUpCost();
       p.canCarry(2);
}
}
interface IVehicle{
	public double tuneUpCost();
	public boolean canCarry(int a);
}
class Mahindra implements IVehicle{
public double tuneUpCost () {
	System.out.println("Cost is 2 lacks");
	return 0;
}
public boolean canCarry(int a) {
	
		if(a<=7) {
			System.out.println("true");
			return true;
		}
		else {
			System.out.println("false");
			return false;
		}
	}
}