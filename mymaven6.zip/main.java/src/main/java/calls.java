package main.java;

public class calls {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int call=280;
       int bill=0;
       if(call==100) {
    	   System.out.println("Free calls");
       }
       else if(call>100 && call<=200) {
    	   bill=(call-100)*1;
    	   System.out.println("Rs 1/call:" +bill);
       }
       else if(call>200 && call<=300) {
    	   bill=(call-200)*2+100;
    	   System.out.println("Rs 2/call:" +bill);
       }
       else if(call>300) {
    	   bill=(call-300)*3+200+100;
    	   System.out.println("Rs3/call:" +bill);
       }	
       }

}
