package day4;

public class power {

	public static void main(String[] args) {
	int base=-3,exponent=2;
	double result=Math.pow(base, exponent);
	System.out.println("Result= "+result);
	}

}
