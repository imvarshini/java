package boo.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
		
		Books b = (Books)context.getBean("b1");
		employee c=(employee)context.getBean("c1");
		b.display();
		c.display();
	}

}
