package main.java;

public class square {
	public static void main(String [] args) {
	int side=10;
	int square=0;
	square=side*side;
	System.out.println("area of square is:"+square);
}
}