package day3;

public class inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Bag g=new Bag();
     g.b();
     g.a();
	}

}
class Box{
	void a() {
		System.out.println("class A");
	}
}
class Bag extends Box {
	void b() {
		System.out.println("class B");
	}
}