package day2;

public class even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         even e=new even();
         e.even1(12);
	}
   public static int even1 (int a) {
	   if(a%2==0)
		   System.out.println("even");
	   else
		   System.out.println("odd");
	   return a;
   }
}
