package day2;

public class scooby {
	 public void area(int side)
	    {
	        System.out.println(side*side);
	    }
	    void area(float radius)
	    {
	        System.out.println(31.4f*radius*radius);
	    }
	    void area(int l,int b)
	    {
	        System.out.println(l*b);
	    }
	    public static void main(String aa[])
	    {
	         
	         scooby t=new scooby();
	         t.area(22.5f);
	         t.area(2);
	         t.area(3,9);
	}
}
