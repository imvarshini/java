package day6;

public class isempty {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Hello_gpg";
String str2="";
System.out.println(str.isEmpty());
System.out.println(str2.isEmpty());
	}

}
