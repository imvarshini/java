package day6;
import java.util.ArrayList;
import java.util.Scanner;
public class demo {
	public static void main(String args[]) {
	
	ArrayList<Studentt> list=new ArrayList<>();//Object

	Studentt s1=new Studentt("varshini", "Present");

    Studentt s2=new Studentt("domnick", "Present");

	Studentt s3=new Studentt("harshitha", "absent");
    Studentt s4=new Studentt("suheb", "Present");

    list.add(s1);

    list.add(s2);

	list.add(s3);

	list.add(s4);

	for( Studentt s:list) {
        System.out.println(s.name+" �"+s.attendence);}

	}
}

	
class Studentt {
String name;
String attendence;
public Studentt(String name,String attendence) {
	super();
	this.name = name;
	this.attendence = attendence;
}
}

