package day2;

public class fibbi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int n=0;
      int n1=1;
      int sum=0;
      int i=1;
      while(i<=20)
      {
    	  
          System.out.println(n);
         
          
    	  sum=n+n1;
    	  
          n=n1;
          n1=sum; 
          i++;
      }
	}

}
