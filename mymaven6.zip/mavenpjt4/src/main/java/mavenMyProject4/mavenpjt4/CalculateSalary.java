package mavenMyProject4.mavenpjt4;
import org.springframework.stereotype.Component;
@Component
public class CalculateSalary {
	int n=50;
		public CalculateSalary() {
		
			int salary=n*1000;
			System.out.println("Total salary: "+salary);
		}
		void display() {
			System.out.println("Total days :"+n);
		}

}
