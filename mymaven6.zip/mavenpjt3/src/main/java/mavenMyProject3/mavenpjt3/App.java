package mavenMyProject3.mavenpjt3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("NewFile.xml");
        Student stud=(Student)context.getBean("addressstud");
        stud.displayaddress();
    }
}
