package main.java;

public class positive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num=-100;
if(num>0) {
	System.out.println("its positive");
}
else
System.out.println("its negative");
	}

}
