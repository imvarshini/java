package day2;

public class fact0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      fact0 f=new fact0();
     
      f.man(1);
      
	}
    void man(int c) {
    	int a=5;
  
    	for(int i=1;i<=a;i++)
    	c=c*i;
    	System.out.println("factorial: "+c);
    
    }
}
