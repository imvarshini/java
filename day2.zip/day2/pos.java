package day2;

public class pos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      pos p=new pos();
      p.positive(1);
	}
 public static int positive(int a) {
	 if(a>=0)
		 System.out.println("positive");
	 else
		 System.out.println("negative");
	 return a;
 }
}
