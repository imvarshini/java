package main.java;

public class rectangle {
public static void main(String[] args ) {
	int length=10;
	int breadth=20;
	int area=0;
	area=length*breadth;
	System.out.println("Area of Rectangle is :" +area);
}
}
