package day4;

public class Bike {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Duke d=new Duke();
d.brake();
	}

}
abstract class MotorBike{
	abstract void brake();
}
class Duke extends MotorBike{

	@Override
	void brake() {
		// TODO Auto-generated method stub
		System.out.println("Front and back break works");
	}
	
}