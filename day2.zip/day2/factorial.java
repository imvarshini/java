package day2;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int fact=5;
         int i=1;
         int sum=0;
         
         while(i<=5){
        	 sum=fact*i;
        	 i++;
         }
         System.out.println(sum);
	}

}
