package day2;

public class tabel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=12;
        int i=1;
        while(i<=10) {
        	System.out.println(a*i);
        	i++;
        }
	}

}
