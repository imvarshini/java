package main.java;

public class electric {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int e=120;
	       int bill=0;
	       if(e==50) {
	    	   System.out.println("Free of cost");
	       }
	       else if(e>50 && e<=100) {
	    	   bill=(e-50)*6;
	    	   System.out.println("electric cost:" +bill);
	       }
	       else if(e>100 && e<=150) {
	    	   bill=(e-100)*8+50*6;
	    	   System.out.println("electric cost:" +bill);
	       }
	       else if(e>150) {
	    	   bill=(e-150)*9+50*6+50*8;
	    	   System.out.println("electric cost:" +bill);
	       }	

	}

}
