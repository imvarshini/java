package main.java;

public class demo {
public static void main(String[] args) {
	int num1=10;
	int num2=5;
	int num3=2;
	int num4=3;
	int num5=1;
	int sum=0;
	sum=num1+num2+num3+num4+num5;
	System.out.println("Sum is :" +sum);
}
}
