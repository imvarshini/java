package day2;

public class fibinoci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int n=0;
       int n1=1;
       int a;
       
       System.out.println(n);
       System.out.println(n1);
       do {
    	  
    	   a=n1+n;
    	   System.out.println(a);
    	   n=n1;
    	   n1=a;
       }
       while(n1<=20);
	}

}
