package day4;

public class abstractClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Tiger n=new Tiger();
       Dog c=new Dog();
       n.makeSound();
       n.eat();
       c.makeSound();
       c.eat();

	}

}
abstract class Animal{
	abstract void makeSound();
	public void eat() {
		System.out.println("What do they eat??");
	}
}
class Tiger extends Animal
{
	public void eat() {
		System.out.println("They eat animals");
	}

	@Override
	void makeSound() {
		// TODO Auto-generated method stub
		System.out.println("They roar");
	}
}
class Dog extends Animal
{
	public void eat() {
		System.out.println("Thay eat food");
	}

	@Override
	void makeSound() {
		// TODO Auto-generated method stub
		System.out.println("They bark");
	}
	
}