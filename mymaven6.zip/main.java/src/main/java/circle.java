package main.java;

public class circle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float pi=3.14f;
		float radius=3;
		float circle=0;
		circle=pi*radius*radius;
		
		System.out.println("area of circle is:"+circle);
	}

}
