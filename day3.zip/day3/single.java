package day3;
import java.util.Scanner;
public class single {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
         Marks m=new Marks();
         m.ReadDetails();
         m.ReadMarks();
         m.DisplayDetails();
         m.DisplayMarks();
	}

}
class Student{
	int studentId;
	String studentName,Phone;
	void ReadDetails() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter student Id:");
		studentId=scan.nextInt();
		System.out.println("Enter student Name:");
		studentName=scan.next();
		
		System.out.println("Enter Pone no:");
		Phone=scan.next();
		
	}
	void DisplayDetails() {
		System.out.println(studentId);
		System.out.println(studentName);
		System.out.println(Phone);
		
	}
}
class Marks extends Student{
	int m1,m2,m3;
	void ReadMarks() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter marks 1:");
		m1=scan.nextInt();
		System.out.println("Enter marks 2:");
		m2=scan.nextInt();
		System.out.println("Enter marks 3:");
		m3=scan.nextInt();
	}
	void DisplayMarks() {
		System.out.println(m1);
		System.out.println(m2);
		System.out.println(m3);
	}
}