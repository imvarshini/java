package main.java;

public class even {
public static void main(String[] args) {
	int n=4;
	if(n%2==0) {
		System.out.println("Its even");
	}
		else
			System.out.println("its odd");
	}

}
