package day2;
import java.util.Scanner;

public class examp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner scan =new Scanner(System.in);
       System.out.print("Enter the name:");
       String name=scan.nextLine();
       System.out.println("My name is:"+name);
       scan.close();
	}

}
