package main.java;

public class first {
public static void main (String[] args) {
	String a="Varshini R";
	String b="Variable Technology";
	int age=22;
	
	System.out.println("My name is "+a+"\n I am learning "+b);
	System.out.println("My Details");
	System.out.println("My name is:" +a);
	System.out.println("Im studying a :" +b);
	System.out.println("My age is:" +age);
}
}
