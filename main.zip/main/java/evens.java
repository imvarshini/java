package main.java;

public class evens {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int n=100;
       int count;
       count=0;
       for(int i=1;i<=n;i++) {
    	   if(i%2==0) {
    		   count=count+i;
    	   }
       }
       System.out.println(count);
	}

}
