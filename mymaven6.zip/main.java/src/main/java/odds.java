package main.java;

public class odds {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
	       int count;
	       count=0;
	       for(int i=1;i<=n;i++) {
	    	   
	    		   count=count+(2*i-1);
	    	   
	       }
	       System.out.println(count);
	}

}
