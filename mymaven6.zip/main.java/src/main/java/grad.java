package main.java;

public class grad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c,d;
		a=10;
		b=7;
		c=15;
		d=45;
		if(a>b && a>c && a>d) {
			System.out.println("a is greater");
		}
		else if(b>a && b>c && b>d){
			System.out.println("b is greater");
		}
		else if(c>a && c>b && c>d) {
			System.out.println("c is greater");
		}
		else {
			System.out.println("d is greater");
		}

       }
	

}
