package day4;

public class swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=3,b=4,t;
System.out.println("Before swapping: " +a+ +b);
t=a;
a=b;
b=t;
System.out.println("After swapping: "+a +b);
	}

}
