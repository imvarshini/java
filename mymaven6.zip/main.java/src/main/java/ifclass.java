package main.java;

public class ifclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int age=18;
        if(age>=18) {
        	System.out.println("User is valid for voting");
        }
        else {
        	System.out.println("User is not allowed for voting");
        }
	}

}
