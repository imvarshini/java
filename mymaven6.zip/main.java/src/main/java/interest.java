package main.java;

public class interest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p,r,q,si;
		p=10;
		r=14;
		q=7;
		si=(p*r*q)/100;
		System.out.println("simple Interest is:"+si);
	}

}
