package boo.demo;

public class Books {

	String publisher;
    int price,id;
	
    public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	void display() {
    	System.out.println("id: "+id+" publisher: "+publisher+" price: "+price);
    }

}
