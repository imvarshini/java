package day5;

public class exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     for(int i=0;i<10;i++) {
    	 try {
    	 if(i==5) {
    		 int count=i/0;
    	 }
    	 }
    	 catch(Exception e) {
    		 System.out.println("Exception caught");
    	 }
    	 System.out.println("total: "+i);
    	 }
	}

}
