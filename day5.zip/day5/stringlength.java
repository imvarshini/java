package day5;

public class stringlength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str="Javaprogrammer";
try {
	if(str.length()>10) {
		System.out.println("The password length match");
	}
	else {
		System.out.println("The password length not match");
		throw new NewLength("The length does not match");
	}
}
catch(NewLength n) {
	System.out.println(n);
}
	}

}
class NewLength extends Exception{
	public NewLength(String message) {
		super(message);
	}
}