package day5;

public class anotherException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        try {
        	String var=null;
        	System.out.println(var.charAt(3));
        }
        catch(Exception e) {
        	System.out.println(e);
        }
        finally {
        	System.out.println("some code !!");
        }
	}

}
