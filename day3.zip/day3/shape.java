package day3;

public class shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Area a1=new Area(3f);
    Area a2=new Area(3);
    Area a3=new Area(4,5);
    a1.getDetail();
    a2.getDetails();
    a3.getDetails();
    
    
    
	}

}
class Area{
	float circle,area1;
	int square,rectangle,area;
	Area(float r){
		float p=3.14f;
		area1=p*r*r;
	}
	Area(int s){
		area=s*s;
	}
	Area(int l, int b){
		area=l*b;
	}
	int getDetail() {
		System.out.println("area: "+area1);
		return area;
	}
	float getDetails() {
		System.out.println("area: " +area);
		return area;
	}
}