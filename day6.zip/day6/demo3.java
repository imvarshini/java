package day6;

import java.util.ArrayList;

public class demo3 {
public static void main(String args[]) {
		
		ArrayList<Book> list=new ArrayList<>();//Object

		Book m1=new Book("wings Of fire",12245,150,"abdul Kalam");
		Book m2=new Book("story of my life",16746,200,"Helen keller");
		

	    list.add(m1);
	    list.add(m2);

		for( Book m:list) {
	        System.out.println(m.name+" �"+m.id+"  "+m.price+"  "+m.author );}

		}
}
class Book {
String name,author;
int id,price;
public Book(String name,int id,int price,String author) {
	super();
	this.name = name;
	this.id=id;
	this.price=price;
	this.author=author;
}
}