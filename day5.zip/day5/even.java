package day5;

import java.util.Scanner;

public class even {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
	     Scanner scan=new Scanner(System.in);
	     System.out.println("Enter the number");
	     num=scan.nextInt();
	     try {
	    	 if(num%2==0) {
	    		 System.out.println("even");}
	    	 else {
	    		 System.out.println("odd");
	    	 throw new Numbers("failed");
	    	 }}
	     catch(Numbers e) {
	    	 System.out.println(e);
	     }
	}

}
class Numbers extends Exception{
	public Numbers(String message) {
		super(message);
	}
}