package day2;

public class task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int a=8;
       int i=1;
       do{
    	   System.out.println(a*i);
    	   i++;
       }
       while(i<=10);
	}

}
