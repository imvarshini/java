package day2;

public class fact {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int fact=5;
       int i=1;
       int sum=0;
       do {
    	   sum=fact*i;
    	   i++;
       }
       while(i<=5);
       System.out.println(sum);
	}
	
}
