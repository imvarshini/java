package main.java;

public class greater {
public static void main(String[] args) {
	int a,b,c;
	a=10;
	b=7;
	c=15;
	if(a>b && a>c) {
		System.out.println("a is greater");
	}
	else if(b>a && b>c){
		System.out.println("b is greater");
	}
	else {
		System.out.println("c is greater");
	}
}
}
