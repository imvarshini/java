package day4;
import java.util.*;
public class reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str="Hello", rstr="";
     char ch;
     System.out.println("original word is:"+str);
     for(int i=0;i<str.length();i++) {
    	 ch=str.charAt(i);
    	 rstr=ch+rstr;
     }
     System.out.println("Reverse of string is:"+rstr);
	}

}
