package main.java;

public class div {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int n=1000;
       int sum=0;
       for(int i=1;i<=n;i++) {
    	   if(i%9==0 && i%3==0) {
    		   System.out.println(i);
    		   sum=sum+i;
        	   
    	   }
    	   
    	   
       }
       System.out.println(sum);
	}

}
