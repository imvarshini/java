package day6;
import java.util.*;
public class remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> a2=new ArrayList<String>();
a2.add("AB");
a2.add("CD");
a2.add("EF");
a2.add("GH");
a2.add("IJ");
a2.add("KL");
System.out.println("ArrayList before remove:");
for(String var:a2) {
	System.out.println(var);
}
a2.remove(0);
a2.remove(2);
a2.remove(2);
System.out.println("array list removed");
for (String var2:a2) {
	System.out.println(var2);
}
	}

}
