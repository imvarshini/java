package day3;

public class constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Car c=new Car("benze   ","   1,23,45,777");
        System.out.println(c.displayDetails());
	}

}
class Car{
	String brandname,price;
	Car(String b, String p){
		brandname=b;
		price=p;
	}
	String displayDetails() {
		return brandname+  ""  +price;
	}
	
}
