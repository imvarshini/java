package day5;
import java.util.*;
public class negative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int num;
     Scanner scan=new Scanner(System.in);
     System.out.println("Enter the number");
     num=scan.nextInt();
     try {
    	 if(num>0)
    		 System.out.println("Positive");
    	 else
    		 System.out.println("negative");
     }
     catch(Exception e) {
    	 System.out.println("Exception thrown");
     }
	}

}
