package day4;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int num=5;
        long fact=number(num);
        System.out.println("factorial is :"+fact);
	}
public static long number(int num) {
	if(num>=1)
		return num*number(num-1);
	else
		return 1;
}
}
