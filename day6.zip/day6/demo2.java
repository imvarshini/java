package day6;

import java.util.ArrayList;

public class demo2 {
public static void main(String args[]) {
		
		ArrayList<Language> list=new ArrayList<>();//Object

		Language m1=new Language("java", 78);

		Language m2=new Language("android", 67);

		Language m3=new Language("ios",80);
		Language m4=new Language("lenux", 75);

	    list.add(m1);

	    list.add(m2);

		list.add(m3);

		list.add(m4);

		for( Language m:list) {
	        System.out.println(m.name+" �"+m.marks);}

		}
}
class Language {
String name;
int marks;
public Language(String name,int marks) {
	super();
	this.name = name;
	this.marks = marks;
}
}