package mavenMyProject4.mavenpjt4;
import org.springframework.beans.factory.annotation.Autowired;
public class Employee {
	@Autowired
CalculateSalary salary;
	private CalculateSalary salary2;

public CalculateSalary getSalary() {
	return salary;
}

public void setSalary(CalculateSalary salary) {
	this.salary = salary;
}
void displaysalary() {
	salary.display();
}
}
