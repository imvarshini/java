package day5;
import java.util.*;
public class student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int marks;
Scanner scan=new Scanner(System.in);
System.out.println("Enter marks for student:");
marks=scan.nextInt();

try {
	if(marks>200) {
		System.out.println("Student passed");}
	else {
		System.out.println("student failed");
		throw new Number("failed");
	}
}
catch(Number e) {
	System.out.println(e);
}

	}

}
class Number extends Exception{
	public Number(String message) {
		super(message);
	}
}