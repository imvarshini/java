package day3;
import java.util.Scanner;
public class example {
	
		String name;
	    int roolNo;
		 void abc(String name) {
	     	this.name=name;
	     	
	     }
	      void abc2(int roolNo) {
	     	this.roolNo=roolNo;
	     
	     }
	      String abc3() {
	    	  
	    	  return name;
	      }
	     int abc4() {
	    	
	    	 return roolNo;
	     }
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	        example s=new example();
	        s.abc("Varsha");
	        s.abc2(1234);
	        s.abc3();
	        s.abc4();
	        
	        System.out.println(s.name);
	        System.out.println(s.roolNo);
	        
	       
		}

	

}
