package day6;
import java.util.*;
public class arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> list=new ArrayList<>();
list.add("java");
list.add("python");
list.add("c");
for(String x:list) {
	System.out.println(x);
}
	}

}
