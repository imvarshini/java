package day5;
import java.util.*;
public class nullPointer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String ptr=null;

try {
	if(ptr.equals("gfg"))
		System.out.println("same");
	else
		System.out.println("Not same");
}
catch(NullPointerException e) {
	System.out.println("Throws exception");
}
	}

}
