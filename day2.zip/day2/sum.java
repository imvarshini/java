package day2;

public class sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int num=100,i=2,sum=0;
      while(i<=num) {
    	  sum=sum+i;
    	  i=i+2;
      }
      System.out.println(sum);
	}

}
