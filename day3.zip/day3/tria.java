package day3;

public class tria {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Triangle t=new Triangle();
        t.display();
	}

}
class Triangle{
	int area,perimeter;
	Triangle(){
		int a,b,c;
		a=3;
		b=4;
		c=5;
		area=(b*a)/2;
		perimeter=a+b+c;
	}
	int display() {
		System.out.println("area of triangle is:  "+area);
		System.out.println("perimeter of triangle is:  "+perimeter);
		return area;
	}
}