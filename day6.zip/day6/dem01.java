package day6;

import java.util.ArrayList;

public class dem01 {
	public static void main(String args[]) {
		
		ArrayList<Student1> list=new ArrayList<>();//Object

		Student1 m1=new Student1("varshini", "78/100" ,"80/100", "91/100");

	    Student1 m2=new Student1("domnick", "69/100", "78/100", "98/100");

		Student1 m3=new Student1("harshitha","80/100", "87/100","98/100");
	    Student1 m4=new Student1("suheb", "75/100", "87/100", "56/100");

	    list.add(m1);

	    list.add(m2);

		list.add(m3);

		list.add(m4);

		for( Student1 m:list) {
	        System.out.println(m.name+" �"+m.marks1+"  "+m.marks2+"  "+m.marks3 );}

		}
}
class Student1 {
String name,marks1;
String marks2,marks3;
int m=100;
public Student1(String name,String marks1,String marks2,String marks3) {
	super();
	//this.m=m;
	this.name = name;
	this.marks1 = marks1;
	this.marks2 = marks2;
	this.marks3 = marks3;
}
}
