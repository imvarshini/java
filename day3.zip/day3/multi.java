package day3;

import java.util.Scanner;

public class multi {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
         Result m=new Result();
         m.ReadDetails();
         m.ReadMarks();
         m.DisplayDetails();
         m.DisplayMarks();
         m.Result();
         m.DisplayResult();
	}

}


class Students{
int studentId;
String studentName,Phone;
void ReadDetails() {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter student Id:");
	studentId=scan.nextInt();
	System.out.println("Enter student Name:");
	studentName=scan.next();
	
	System.out.println("Enter Pone no:");
	Phone=scan.next();
	
}
void DisplayDetails() {
	System.out.println("student id id:"+studentId);
	System.out.println("Student Name is: "+studentName);
	System.out.println("Phone no is: "+Phone);
	
}
}
class Markss extends Students{
int m1,m2,m3;
void ReadMarks() {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter marks 1:");
	m1=scan.nextInt();
	System.out.println("Enter marks 2:");
	m2=scan.nextInt();
	System.out.println("Enter marks 3:");
	m3=scan.nextInt();
}
void DisplayMarks() {
	System.out.println("Marks 1: "+m1);
	System.out.println("Marks 2: "+m2);
	System.out.println("Marks 3: "+m3);
}
}
class Result extends Markss{
	int TotalMarks,Percentage;
	String Grade;
	void Result() {
		Scanner scan=new Scanner(System.in);
		TotalMarks=m1+m2+m3;
		Percentage=TotalMarks/3;
		if(Percentage>=80) {
			Grade="First Class";
			
		}
		
		else if(Percentage>=60 && Percentage<80) {
			Grade="Second Class";
		}
		else if(Percentage>=45 && Percentage<60) {
			Grade="Third Class";
		}
		else
		     Grade="fail";
	}
	void DisplayResult(){
		System.out.println("Total marks is : "+TotalMarks);
		System.out.println("Percentage : "+Percentage);
		System.out.println("Grade: "+Grade);
	}
}