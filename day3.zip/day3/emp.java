package day3;

public class emp {
	String name;
    int rollno;
    emp(String n,int r){
    	name=n;
    	rollno=r;
    }
    void display() {
    	System.out.println(name+""+rollno);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp s1=new emp("var  ", 111);
        emp s2=new emp("tom  ", 112);
        emp s3=new emp("jerry  ",113);
        s1.display();
        s2.display();
        s3.display();
	}

}
