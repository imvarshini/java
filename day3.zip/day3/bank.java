package day3;
import java.util.Scanner;
public class bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BalanceInquiry a=new BalanceInquiry();
		withdrawal b=new withdrawal();
		//deposit c=new deposit();
		a.execute1();
       a.execute4();
       a.execute3();
       a.executes2();
      
    
  
       
	}

}
class Transaction{
	int accNo, amount,totalamt,draw;
	void getAccountNumber() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter account number:");
		accNo=scan.nextInt();
		System.out.println("Total amount:"+amount);
		
	}
	void execute1() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter account number:");
		accNo=scan.nextInt();
		System.out.println("Account no is"+accNo);
		
	}
}
class BalanceInquiry extends withdrawal{
	void executes2() {
		Scanner scan=new Scanner(System.in);
		
	
		System.out.println("Balance account:"+totalamt);
	}
}
class withdrawal extends deposit{
	int draw,totalamt;
	void execute3() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter amount you want to draw:");
		draw=scan.nextInt();
	
		totalamt = amount-draw;
		System.out.println("Balance account:" +totalamt);
		
	}
}
class deposit extends Transaction{
	int amount;
	void execute4() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the amount to be added:");
		amount=scan.nextInt();
		System.out.println("Total amount:"+amount);
	}
}