package day4;
import java.util.*;
public class vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int count=0;
       System.out.println("Enter the sentence:");
       Scanner s=new Scanner(System.in);
       String sentence=s.nextLine();
       for(int i=0;i<sentence.length();i++) {
    	   char ch=sentence.charAt(i);
    	   if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
    		   count++;
    	   }
       }
       System.out.println("no of vowels"+count);
	}

}
