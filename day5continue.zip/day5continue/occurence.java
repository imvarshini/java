package day5continue;

import java.util.Scanner;

public class occurence {
	public static void main(String[] args) {
	int count=0;
	System.out.println("Enter the sentence");
	Scanner scan=new Scanner(System.in);
	String c=scan.nextLine();
	 
	for(int i=0;i<c.length();i++) {
		char ch=c.charAt(i);
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
			System.out.println("Given string contains "+c.charAt(i)+"  at the index "+i);	
		}
	}
	//System.out.println("number of times vowel occurs:"+count);
		}
}
