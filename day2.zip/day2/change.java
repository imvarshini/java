package day2;

public class change {
      int  a=9;
      static int b=20;
      void changeVariable() {
    	  a=10;
    	  b=100;
      }
     
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         change c1=new change();
         change c2=new change();
         change c3=new change();
         c1.changeVariable();
         
         System.out.println("a:"+c1.a);
         System.out.println("a:"+c2.a);
         System.out.println("a:"+c3.a);
         System.out.println("b:"+c1.b);
         System.out.println("b:"+c2.b);
         System.out.println("b:"+c3.b);
	}

}
