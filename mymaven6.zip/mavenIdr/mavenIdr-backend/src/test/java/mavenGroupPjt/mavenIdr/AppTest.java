package mavenGroupPjt.mavenIdr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppTest {

    @Test
    void contextLoads() {
    }
}
