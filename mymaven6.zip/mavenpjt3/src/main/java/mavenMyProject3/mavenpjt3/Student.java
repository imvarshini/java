package mavenMyProject3.mavenpjt3;
import org.springframework.beans.factory.annotation.Autowired;
public class Student {
	@Autowired
Address address;

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}
void displayaddress() {
	address.display();
}
}
