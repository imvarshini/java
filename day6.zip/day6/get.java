package day6;
import java.util.*;
public class get {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer>list=new LinkedList<>();
for(int i=0;i<6;i++) {
	list.add(i);
	int index=list.get(i);
	System.out.println("Element "+i+ "  stored at index"+index);
}
	}

}
