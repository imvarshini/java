package day2;

public class sums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    sums s=new sums();
    s.mains(100);
	}
	public static int mains(int a ) {
		int i,sum=0;
		for(i=1;i<=a;i++) {
			sum=sum+i;
		}
		System.out.println("sum: "+sum);
		return sum;
	}

}
