package main.java;

public class grades {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int a,b,c,d;
       d=15;
       b=20;
       c=30;
       a=b+c+d;
       if(a==45 && a<60) {
    	   System.out.println("just-pass:D");
       }
       else if(a>60 && a<70) {
    	   System.out.println("pass Grade:c");
       }
       else if(a>70 && a<85) {
    	System.out.println("pass distinction Grade:B");   
       }
       else if(a>85) {
    	   System.out.println("Excellent Grade:A");
       }
       else
    	   System.out.println("fail");
	}
    
}
