package mavenMyProject.mavenNo;

public class Student {
	String name,id;
public Student() {
	
}



public Student(String name, String id) {
	
	this.name = name;
	this.id = id;
}
void display() {
	System.out.println("Name :"+name+" Id:"+id);
}
}
