package day2;
import java.util.Scanner;
public class calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch1,ch2,result;
	
		String choice;
       Scanner scan= new Scanner(System.in);
       do {
           System.out.print("Enter first no"); //3
           ch1= scan.nextInt();  //4
           System.out.print("Enter second no");
           ch2= scan.nextInt(); 
           System.out.print("Select your operation :\n1.Addition\n2.Sub\n3.Mul\n4.Div");
           int op=scan.nextInt();
           if(op==1)
           {
               System.out.print("Addition :"+(ch1+ch2));
           }
           else if(op==2)
           {
               System.out.print("Subtraction :"+(ch1-ch2));
           }
           else if(op==3)
           {
               System.out.print("Mul :"+(ch1*ch2));
           }
           else if(op==4)
           {
               System.out.print("Division :"+(ch1/ch2));
           }else
           {
    
               System.out.print("Enter valid choice(1,2,3,4)");
           }
           System.out.print("Do you want to continue?(yes/no)");
           choice=scan.next();
           }
           while(choice.equals("YES")|| choice.equals("yes"));
           System.out.print("Thankyou!!!");
	}

}
