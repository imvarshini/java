package day3;

import java.util.Scanner;

public class hierarchial {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		Marksss k=new Marksss();
		Exam e=new Exam();
         k.ReadDetails();
         k.ReadMarks();
         e.Read();

         k.DisplayDetails();
         k.DisplayMarks();
         
         e.Display();
	}

}


class Studentss{
int studentId;
String studentName,Phone;
void ReadDetails() {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter student Id:");
	studentId=scan.nextInt();
	System.out.println("Enter student Name:");
	studentName=scan.next();
	
	System.out.println("Enter Pone no:");
	Phone=scan.next();
	
}
void DisplayDetails() {
	System.out.println("student id id:"+studentId);
	System.out.println("Student Name is: "+studentName);
	System.out.println("Phone no is: "+Phone);
	
}
}
class Marksss extends Studentss{
int m1,m2,m3;
void ReadMarks() {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter marks 1:");
	m1=scan.nextInt();
	System.out.println("Enter marks 2:");
	m2=scan.nextInt();
	System.out.println("Enter marks 3:");
	m3=scan.nextInt();
}
void DisplayMarks() {
	System.out.println("Marks 1: "+m1);
	System.out.println("Marks 2: "+m2);
	System.out.println("Marks 3: "+m3);
}
}

class Exam extends Studentss{
	int m4,m5,m6;
	void Read() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter marks 4:");
		m4=scan.nextInt();
		System.out.println("Enter marks 5:");
		m5=scan.nextInt();
		System.out.println("Enter marks 6:");
		m6=scan.nextInt();
	}
	void Display() {
		System.out.println("Marks 4: "+m4);
		System.out.println("Marks 5: "+m5);
		System.out.println("Marks 6: "+m6);
	}
}
