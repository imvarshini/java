package day4;

public class xstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String input="aaaabbbbccccdsd";
char search='a';
int count=0;
for(int i=0;i<input.length();i++) {
	if(input.charAt(i)==search)
		count++;
}
System.out.println("no of occurences"+count);
	}

}
