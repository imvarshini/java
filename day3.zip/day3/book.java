package day3;

public class book {
    String author;
    int bookid,price;
    book(int i,int p, String a){
    	bookid=i;
    	price=p;
    	author=a;
    }
    void bookDetails() {
    	System.out.println(bookid+  "  "+price+  "  "+author);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       book b=new book(112,250,"Tagore");
       b.bookDetails();
	}

}
