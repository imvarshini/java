package day4;
import java.util.*;
public class ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      char c;
      for(c='A';c<='Z';c++) {
    	  int asciiValue=c;
    	  System.out.println("The ascii value"+c+" is: "+asciiValue);	 
      }
      
	
	}

}
