package day2;

public class whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int a=8;
        do {
        	System.out.println(a*5);
        	a++;
        }
              while(a<=10) ;
            
        
        
	
     }

}
