package day6;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
public class addall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set<Integer>set=new HashSet<>();
ArrayList<Integer> arrlist2=new ArrayList<Integer>();
arrlist2.add(10);
arrlist2.add(20);
arrlist2.add(30);
arrlist2.add(40);
boolean b=Collections.addAll(set, 1,2,3,4,5);
System.out.println("Bollean Result: "+b);
System.out.println("Collection value: "+set);

System.out.println("ArrayList value before:" +"removeAll() operation:" +arrlist2);
arrlist2.removeAll(arrlist2);
System.out.println("ArrayList  after removal(): "+arrlist2);


	}

}
