package day2;

public class sumwhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int num=100,i=2,sum=0;
         do {
        	 sum=sum+i;
        	 i=i+2;
         }
         while(i<=num);
         System.out.println(sum);
	}

}
