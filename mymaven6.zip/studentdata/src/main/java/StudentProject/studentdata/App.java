package StudentProject.studentdata;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


/**
 * Hello world!
 *
 */
public class App 
{
   

	public static void main( String[] args )
    {
		ApplicationContext  context=new ClassPathXmlApplicationContext("config.xml");
   	 sudentsOperations op=(sudentsOperations)context.getBean("operationdemo");
   	 
   	 sudents e1=new sudents();
   	 e1.setEmail("xyzk.jsgchj");
   	 e1.setId("123");
   	 e1.setName("varshini");
   	 e1.setSalary("400000");
   	 
	int result=     op.insert(e1);
System.out.print(result);
   	
    }
}
