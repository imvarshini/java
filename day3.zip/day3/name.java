package day3;

public class name {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Employee e = new Employee();
       
	}

}
class Employee{
	String name;
	Employee(String name){
		this.name=name;
		System.out.println("The name of the Student is "+name);
		}
		Employee(){
		System.out.println("The name of the Student is unknown ");
		}

	
	
		
}